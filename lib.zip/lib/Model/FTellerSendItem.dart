class FTSendItem {
  int id;
  String title;
  FTSendItem(this.id, this.title);
}