class FortuneTellEntity {
  int id;
  String title;
  String iconPath;
  FortuneTellEntity(this.id, this.title, this.iconPath);
}