class RequestBottomMenuItemEntity {
  int id;
  String title;
  String iconPath;
  RequestBottomMenuItemEntity({
    this.id,
    this.title,
    this.iconPath,
  });
}
