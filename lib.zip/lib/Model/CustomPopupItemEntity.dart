class CustomPopupMenuItem {
  int value;
  String title;
  CustomPopupMenuItem(this.value, this.title);
}

class CustomDropDownMenuItem {
  int value;
  String title;
  CustomDropDownMenuItem(this.value, this.title);
}
