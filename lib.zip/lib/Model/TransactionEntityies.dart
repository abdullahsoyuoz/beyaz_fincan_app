class CreditTransactionsEntity {
  int id;
  String title;
  CreditTransactionsEntity(this.id, this.title);
}

class OtherTransactionsEntity {
  int id;
  String title;
  OtherTransactionsEntity(this.id, this.title);
}

class AppTransactionsEntity {
  int id;
  String title;
  AppTransactionsEntity(this.id, this.title);
}