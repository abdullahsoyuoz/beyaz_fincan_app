class CreditPkgEntity {
  int id;
  String title;
  int credit;
  int fee;
  String iconPath;
  CreditPkgEntity(this.id, this.title, this.credit, this.fee, this.iconPath);
}