String appAssetsPathBg1 = "assets/images/back1.png";
String appAssetsPathBg1L = "assets/images/back1L.png";
String appAssetsPathRate = "assets/icons/rate.png";
String appAssetsPathCredit = "assets/icons/credit.png";
String appAssetsPathCurrency = "assets/icons/currency.png";
String appAssetsPathInstagram = "assets/icons/instagram.png";
String appAssetsPathTrash = "assets/icons/trash.png";
String appAssetsPathCinema = "assets/icons/cinema.png";
String appAssetsPathElFalScrIcon = "assets/images/elFalScreenSendIcon.png";
String appAssetsPathCardPattern = "assets/images/cardPattern.png";

String appAssetsPathRBMenuKahve = "assets/icons/requestBottomMenuKahve.png";
String appAssetsPathRBMenuEl = "assets/icons/requestBottomMenuEl.png";
String appAssetsPathRBMenuYuz = "assets/icons/requestBottomMenuYuz.png";
String appAssetsPathRBMenuTarot = "assets/icons/requestBottomMenuTarot.png";

String appAssetsFalBurc = "assets/images/burc.png";
String appAssetsFalYuz = "assets/images/falYuz.png";
String appAssetsFalEl = "assets/images/falEl.png";
String appAssetsFalKahve = "assets/images/falKahve.png";
String appAssetsFalTarot = "assets/images/falTarot.png";
String appAssetsFalRuyaYorum = "assets/images/ruyaYorum.png";

String appAssetsBurcAkrep = "assets/images/burcAkrep.png";
String appAssetsBurcAslan = "assets/images/burcAslan.png";
String appAssetsBurcBalik = "assets/images/burcBalik.png";
String appAssetsBurcBasak = "assets/images/burcBasak.png";
String appAssetsBurcBoga = "assets/images/burcBoga.png";
String appAssetsBurcIkizler = "assets/images/burcIkizler.png";
String appAssetsBurcKoc = "assets/images/burcKoc.png";
String appAssetsBurcKova = "assets/images/burcKova.png";
String appAssetsBurcOglak = "assets/images/burcOglak.png";
String appAssetsBurcTerazi = "assets/images/burcTerazi.png";
String appAssetsBurcYay = "assets/images/burcYay.png";
String appAssetsBurcYengec = "assets/images/burcYengec.png";