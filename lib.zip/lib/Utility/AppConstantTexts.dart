String testDataEntrySubTitle =
    'Hesabın hala yok mu\nhemen başla butonunu takip ederek\nbir hesap oluşturabilir veya giriş yapabilirsiniz?';

String contactUsContext =
    'Lütfen aşağıdaki form yardımıyla bizimle bağlantı kurarak size daha iyi hizmet sunabilmek için düşüncelerinizi bizimle paylaşın…';

String aboutUsContent = 'Beyaz Fincan Hakkında aramızda kalsın';

String aboutUsContent2 = 'İletişiminizin ön planda olabileceği bir gündesiniz. Yakın çevreniz ile girdiğiniz diyaloglarda fikirleriniz ve bunları sunma tarzınız etkileyeceği sonuçlar getirebilir. Konuşmak istediğiniz konular varsa bu fırsatı değerlendirmelisiniz.İletişiminizin ön planda olabileceği bir gündesiniz. Yakın çevreniz ile girdiğiniz diyaloglarda fikirleriniz ve bunları sunma tarzınız etkileyeceği sonuçlar getirebilir. Konuşmak istediğiniz konular varsa bu fırsatı değerlendirmelisiniz.İletişiminizin ön planda olabileceği bir gündesiniz. Yakın çevreniz ile girdiğiniz diyaloglarda fikirleriniz ve bunları sunma tarzınız etkileyeceği sonuçlar getirebilir. Konuşmak istediğiniz konular varsa bu fırsatı değerlendirmelisiniz.';